package codechicken.nei;

public class NEIClientConfig {

}
