package codechicken.nei.recipe;

public class GuiRecipe {

}
