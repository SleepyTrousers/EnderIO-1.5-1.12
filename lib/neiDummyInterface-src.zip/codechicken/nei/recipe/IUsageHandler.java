package codechicken.nei.recipe;

public interface IUsageHandler {

}
