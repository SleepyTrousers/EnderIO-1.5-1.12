package codechicken.nei.api;

public interface IOverlayHandler {

}
