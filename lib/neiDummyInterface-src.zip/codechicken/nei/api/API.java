package codechicken.nei.api;

import net.minecraft.client.gui.inventory.GuiContainer;
import codechicken.nei.recipe.ICraftingHandler;

public class API {

  public static void registerRecipeHandler(ICraftingHandler sagMillRecipeHandler) {
    // TODO Auto-generated method stub

  }

  public static void setGuiOffset(Class<? extends GuiContainer> classz, int x, int y) {
    // TODO Auto-generated method stub

  }

  public static void hideItem(int blockID) {
    // TODO Auto-generated method stub

  }

}
