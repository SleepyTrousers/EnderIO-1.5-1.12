package codechicken.nei.api;

public interface IConfigureNEI {

  void loadConfig();

  String getName();

  String getVersion();

}
