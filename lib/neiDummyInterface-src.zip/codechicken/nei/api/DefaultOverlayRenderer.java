package codechicken.nei.api;

public class DefaultOverlayRenderer {

}
