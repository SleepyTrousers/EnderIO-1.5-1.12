package codechicken.nei.api;

public interface IStackPositioner {

}
