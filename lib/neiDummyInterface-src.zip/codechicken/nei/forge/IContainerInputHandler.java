package codechicken.nei.forge;

import net.minecraft.client.gui.inventory.GuiContainer;

public interface IContainerInputHandler {

  boolean lastKeyTyped(GuiContainer gui, char keyChar, int keyCode);

  boolean mouseClicked(GuiContainer gui, int mousex, int mousey, int button);

  void onKeyTyped(GuiContainer gui, char keyChar, int keyID);

  public void onMouseClicked(GuiContainer gui, int mousex, int mousey, int button);

  public void onMouseUp(GuiContainer gui, int mousex, int mousey, int button);

  public boolean keyTyped(GuiContainer gui, char keyChar, int keyID);

  public boolean mouseScrolled(GuiContainer gui, int mousex, int mousey, int scrolled);

  public void onMouseScrolled(GuiContainer gui, int mousex, int mousey, int scrolled);

}
