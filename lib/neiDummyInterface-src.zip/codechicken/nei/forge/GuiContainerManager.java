package codechicken.nei.forge;

public class GuiContainerManager {

  public void bindTexture(String guiTexture) {
    // TODO Auto-generated method stub

  }

  public void drawTexturedModalRect(int i, int j, int k, int l, int m, int n) {
    // TODO Auto-generated method stub

  }

  public void drawText(int i, int j, String energyString, int k) {
    // TODO Auto-generated method stub

  }

}
