package codechicken.nei;

import net.minecraft.item.ItemStack;

public class PositionedStack {

  public ItemStack item;

  public PositionedStack(ItemStack itemStack, int i, int j) {
    // TODO Auto-generated constructor stub
  }

}
