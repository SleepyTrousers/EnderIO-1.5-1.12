package ic2.api.item;


public interface IBlockCuttingBlade {
	int gethardness();
}
