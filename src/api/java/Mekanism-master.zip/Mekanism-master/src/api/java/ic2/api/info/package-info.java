@API(apiVersion="1.0", owner="IC2", provides="IC2API")
package ic2.api.info;
import cpw.mods.fml.common.API;

